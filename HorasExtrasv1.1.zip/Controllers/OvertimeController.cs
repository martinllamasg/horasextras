
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HorasExtrasAppClean.Models;
using HorasExtrasAppClean.Services;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HorasExtrasAppClean.Controllers
{
    [Authorize]
    public class OvertimeController : Controller
    {
        private readonly FileStorageService _storageService;

        public OvertimeController(FileStorageService storageService)
        {
            _storageService = storageService;
        }

        public IActionResult Create()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewBag.UserId = userId;
            return View(new OvertimeEntryModel());
        }

        [HttpPost]
        public async Task<IActionResult> Create(OvertimeEntryModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var savedPaths = await _storageService.SaveFilesAsync(model.Files);

            // Aquí simularíamos guardar a base de datos con días, descripciones y rutas de archivo
            // Por ahora, podrías guardar en una base como Azure SQL si se requiere

            TempData["Message"] = $"Guardado {savedPaths.Count} archivo(s) correctamente.";
            return RedirectToAction("Create");
        }
    }
}
