
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HorasExtrasAppClean.Models
{
    public class OvertimeEntryModel
    {
        [Required]
        public List<List<int>> Days { get; set; } = new List<List<int>>();

        [Required]
        public List<string> Descriptions { get; set; } = new List<string>();

        [Required]
        public List<IFormFile> Files { get; set; } = new List<IFormFile>();
    }
}
