
using Microsoft.EntityFrameworkCore;
using HorasExtrasAppClean.Models;

namespace HorasExtrasAppClean.Data
{
    public class OvertimeDbContext : DbContext
    {
        public OvertimeDbContext(DbContextOptions<OvertimeDbContext> options)
            : base(options)
        {
        }

        public DbSet<OvertimeEntry> OvertimeEntries { get; set; }
        public DbSet<OvertimeRow> OvertimeRows { get; set; }
        public DbSet<OvertimeHour> OvertimeHours { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OvertimeRow>()
                .HasOne(r => r.Entry)
                .WithMany(e => e.Rows)
                .HasForeignKey(r => r.OvertimeEntryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<OvertimeHour>()
                .HasOne(h => h.Row)
                .WithMany(r => r.Hours)
                .HasForeignKey(h => h.OvertimeRowId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }

    public class OvertimeEntry
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public DateTime WeekDate { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public ICollection<OvertimeRow> Rows { get; set; }
    }

    public class OvertimeRow
    {
        public int Id { get; set; }
        public int OvertimeEntryId { get; set; }
        public OvertimeEntry Entry { get; set; }
        public string SelectedDays { get; set; }
        public string Description { get; set; }
        public string? FilePath { get; set; }
        public ICollection<OvertimeHour> Hours { get; set; }
    }

    public class OvertimeHour
    {
        public int Id { get; set; }
        public int OvertimeRowId { get; set; }
        public OvertimeRow Row { get; set; }
        public string DayName { get; set; }
        public double Hours { get; set; }
    }
}
