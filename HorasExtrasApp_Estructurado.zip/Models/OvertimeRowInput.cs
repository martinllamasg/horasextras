
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HorasExtrasAppClean.Models
{
    public class OvertimeRowInput
    {
        public List<string> SelectedDays { get; set; } = new List<string>();

        public Dictionary<string, double> Hours { get; set; } = new Dictionary<string, double>();

        [Required]
        public string Description { get; set; } = string.Empty;

        public IFormFile FileUpload { get; set; }
    }
}
